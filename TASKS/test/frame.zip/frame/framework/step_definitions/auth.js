var authPage=require('../po/page/authPage');
var {defineSupportCode} = require('cucumber');

defineSupportCode(function({When}){
	When(/^I submit login form$/, function(){
		return authPage.submitForm();
	});
});

// var AuthSteps=function(){
// 	this.When(/^I submit login form/, function(){
// 		return authPage.submitForm();
// 	});


// };

// module.exports=AuthSteps;

