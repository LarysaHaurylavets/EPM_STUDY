var ratingPage=require('../po/page/ratingPage');

var {defineSupportCode} = require('cucumber');

defineSupportCode(function({Then,setDefaultTimeout}){
	Then(/^I set filters$/, function(){
		return ratingPage.setFilters();
	});
});