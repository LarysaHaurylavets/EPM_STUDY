var page = require('../po/page/basePage');
var provider = require('../po/page/poProvider');
var {defineSupportCode} = require('cucumber');

defineSupportCode(function({Given}){
	Given(/^I am on "([^"]*)" page$/, function (pageName) {
        return provider.getPageObjects(pageName).visit();
	});
});

// var CommonSteps = function () {

//     this.Given(/^I am on "([^"]*)" page$/, function (pageName) {
//         return provider.getPageObjects(pageName).visit();
//     });

   

// };

// module.exports = CommonSteps;