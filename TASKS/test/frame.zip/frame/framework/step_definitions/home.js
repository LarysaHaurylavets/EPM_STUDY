var homePage=require('../po/page/homePage');

var {defineSupportCode} = require('cucumber');

defineSupportCode(function({When, setDefaultTimeout}){
	When(/^I open login form$/, function () {
        return homePage.followLinkLogin();
    });
});

// var HomeSteps=function(){
// 	this.Given(/^I am on "([^"]*)" page$/, function (pageName) {
//         return provider.getPageObjects(pageName).visit();
//     });
// };

// module.exports = HomeSteps;