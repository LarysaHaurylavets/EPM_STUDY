var userPage=require('../po/page/userPage');
var {defineSupportCode} = require('cucumber');

defineSupportCode(function({Then, setDefaultTimeout}){
	Then(/^User page should be displayed$/, function () {
        return userPage.userPageShouldBeDisplayed();
    });
	Then(/^I choose logic game$/, function () {
        return userPage.userPagelinkGame();
    });

    Then(/^I start game$/, function () {
        return userPage.userStartGame();
    });
    
    Then(/^I logout from user page$/, function () {
        return userPage.userLogout();
    });
});


// var UserSteps=function (){
// 	this.Then(/^User page should be displayed/, function () {
//         return userPage.userPageShouldBeDisplayed();
//     });
// };

// module.exports=UserSteps;