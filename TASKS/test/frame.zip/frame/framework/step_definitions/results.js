var resultsPage = require('../po/page/resultsPage');
var provider = require('../po/page/poProvider');
var {defineSupportCode} = require('cucumber');

defineSupportCode(function({Then, setDefaultTimeout}){
	Then(/^I should see a list of pupils$/, function () {
        return resultsPage.checkImagesResults();
    });
});