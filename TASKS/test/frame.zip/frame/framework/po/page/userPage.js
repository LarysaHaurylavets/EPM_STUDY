var chai = require('chai');
var expect = chai.expect;
var EC=protractor.ExpectedConditions;

var BasePage=require('./basePage');

function UserPage(){
	var self=this;
	this.url='https://logiclike.com/user#/service/logic';
	this.profile=element(by.binding('profile.name'));
	//this.game=element(by.linkText('Логические игры'));
	this.gameList=element(by.css('a[href^="/user#/store/logic-games"]'));
	this.gameName=element(by.css('a[href^="/game/battleship"]'));
	// this.buttonWithLevel=element(by.xpath('//*[@id="content"]/div/canvas[6]'));
	// this.buttonWithBegin=element(by.xpath('//*[@id="content"]/div/canvas[10]'));
	this.gameOut=element(by.css('#content > div > canvas:nth-child(29)'));
	this.exit=element(by.linkText('Выход'));


	this.userPageShouldBeDisplayed=function(){		
		return browser.wait(EC.presenceOf(self.profile),10000).then(function(){
			return self.profile.isPresent();
		});		
	};

	this.userPagelinkGame=function(){		
		browser.sleep(5000);
		return self.gameList.click().then(function(){
			self.gameName.click();
		})		
	};

	this.userStartGame=function(){
		browser.waitForAngularEnabled(false);
		browser.sleep(7000);		
	};

	this.userLogout=function(){
		browser.navigate().back();
		browser.sleep(5000);
		return self.exit.click();
		
		// return browser.wait(EC.visibilityOf(self.exit),5000)
		// 	.then(function(){
		// 		return self.exit.click();
		// 	})
		// 	.then(function(){
		// 		return (require('../page/authPage'));
		// 	})
		// return browser.wait(EC.elementToBeClickable(self.exit),10000)
		// 	.then(function(){
		// 		return self.exit.click();
		// 	});
	}

}

UserPage.prototype=BasePage;
module.exports=new UserPage();


//