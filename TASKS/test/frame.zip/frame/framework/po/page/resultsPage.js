var expect=require('chai').expect;
var BasePage=require('./basePage');

function ResultsPage(){

	this.imageResults=element.all(by.className('rating-page__content__avatar'));

	this.checkImagesResults=function(){
		var self=this;
		return self.imageResults.count().then(function(number){
			expect(number).to.be.above(0);
		})

	}

}

ResultsPage.prototypr=BasePage;
module.exports=new ResultsPage();