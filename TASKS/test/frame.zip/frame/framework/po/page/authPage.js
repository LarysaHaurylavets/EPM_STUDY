var BasePage = require('./basePage');
var EC=protractor.ExpectedConditions;

function AuthPage(){

	this.url='https://logiclike.com/auth/login#/auth';

	this.email=element(by.model('authentication.login'));
	this.password=element(by.model('authentication.password'));
	this.confirm=element(by.buttonText('Войти'));


	this.submitForm=function(){
		var self=this;
		browser.sleep(5000);
		return self.email.sendKeys('glar4ik@gmail.com')
			.then(function(){
				return self.password.sendKeys('real82')
			})
			.then(function(){
				return browser.wait(EC.elementToBeClickable(self.confirm),10000).then(function(){
					return self.confirm.click();
				})
			})
			.then(function(){
				return require('../page/userPage');
			})
			// .then(function(){
			// 	return require('../page/ratingPage');
			// })

	};

}

AuthPage.prototype=BasePage;
module.exports=new AuthPage();



// browser.wait(EC.elementToBeClickable(page.confirm),6000).then(function(element){
//         return element.click();
//       });  