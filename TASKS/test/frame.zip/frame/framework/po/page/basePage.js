var BasePage=function(){
	
	this.visit = function () {
        return browser.get(this.url);
    };

    this.checkPageTitle = function (pageTitle) {
        return browser.getTitle().then(function (title) {
            return title === pageTitle;
        });
    };


    this.clickWhenClickable = function (locator, timeout) {
	    browser.wait(function () {
	        return browser.findElement(locator).then(function (element) {
	            return element.click().then(function () {
	                return true;
	            }, function (err) {
	                return false;
	            })
	        }, function (err) {
	            return false;
	        });
	    }, timeout, 'Timeout waiting for ' + locator.value);    
	}



};


module.exports = new BasePage();