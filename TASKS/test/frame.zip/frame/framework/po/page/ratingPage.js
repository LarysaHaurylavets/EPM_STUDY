var BasePage = require('./basePage');
var EC=protractor.ExpectedConditions;
var chai = require('chai');
var expect = chai.expect;



function RatingPage(){

	this.url='https://logiclike.com/rating';

	this.allCountries=element(by.css('.rating-page__select__country-icon'));
	this.country=element.all(by.repeater('item in $parent.$parent.regionList')).get(1);

	this.allCity=element.all(by.binding('$parent.selectedCity.cityName')).first();
	this.city=element.all(by.repeater('item in $parent.$parent.cityList')).get(1);

	this.allSchools=element.all(by.binding('$parent.selectedInstitution.institutionName')).first();
	this.school=element.all(by.binding('item.institutionName')).get(9);

	this.class=element.all(by.binding('.ratingTitle')).get(3);
	this.allClasses=element.all(by.binding('$parent.selectedGrade.ratingTitle')).first();

	//this.pupilName=element.all(by.binding('item.displayName')).get(1);
	
	this.setFilters=function(){
		var self=this;

		// return browser.wait(EC.elementToBeClickable(self.allCountries),10000).then(function(){
		// 	return self.allCountries.click();
		// })
		return waitForElementAndClick(self.allCountries)
			.then(function(){				
				return self.country.click();
			})
			.then(function(){
				return self.allCity.click();
			})
			.then(function(){
				return self.city.click();
			})
			.then(function(){
				return self.allSchools.click();
			})
			.then(function(){
				return self.school.click();
			})
			.then(function(){
				return self.allClasses.click();
			})
			.then(function(){
				return self.class.click();
			})
			.then(function(){
				return require('../page/resultsPage');
			})
	};

}

RatingPage.prototype=BasePage;
module.exports=new RatingPage();


function waitForElementAndClick(locator){
	return browser.wait(EC.elementToBeClickable(locator)).then(function(){
		return locator.click();
	})
}

// function waitForElementToBePresent(element){

// 	browser.wait(function () {
// 	return element.isPresent();
// 	},60000);

// 	browser.wait(function () {
// 	return element.isDisplayed();
// 	},60000);
// };