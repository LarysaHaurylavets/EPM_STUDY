var expect = require('chai').expect;
var EC=protractor.ExpectedConditions;


var BasePage=require('./basePage');

function HomePage(){
	var self=this;
	this.url='https://logic.by/';
	this.linkLogin=element(by.linkText('Войти в личный кабинет'));
	this.base=BasePage;

	this.homePageShouldBeDisplayed=function(){		
		return self.logo.isDisplayed().then(function(isDisplayed){
			return expect(isDisplayed).to.be.true;
		});
	};


	this.followLinkLogin=function(){	
		browser.sleep(5000);
		return browser.wait(EC.presenceOf(self.linkLogin),10000).then(function(element){
			return self.linkLogin.click();
		})

		.then(function(){
			return require('../page/authPage');
		})
		// return self.linkLogin.click().then(function(){
		// 	return require('../page/authPage');
		// })
	}
	
}

HomePage.prototype=BasePage;
module.exports=new HomePage();