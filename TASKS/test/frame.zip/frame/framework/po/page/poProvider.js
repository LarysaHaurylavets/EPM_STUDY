var PAGE_OBJECT_MAP={
	'auth': './authPage',
	'home': './homePage',
	'user': './userPage',
	'rating': './ratingPage'
};

module.exports.getPageObjects=function(pageName){
	return require(PAGE_OBJECT_MAP[pageName]);
};